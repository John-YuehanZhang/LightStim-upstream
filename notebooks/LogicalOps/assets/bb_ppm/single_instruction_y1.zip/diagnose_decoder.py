#!/usr/bin/env python3
"""Retain input shots and expose Relay-BP convergence without changing decoding.

Example: --shots 50 --shot-indices 0,1,2,3 samples the same 50-shot batch as
the Notebook and decodes only four rows. --input-samples reuses a saved batch.
This program never writes to the source circuit, source repository, or old run.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import sys
import time


PARAMETERS = dict(alpha=1.0, gamma0=0.125, pre_iter=80, num_sets=600,
                  set_max_iter=60, gamma_dist_interval=(-0.24, 0.66),
                  stop_nconv=5, stopping_criterion="nconv", logging=False,
                  seed=0)


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def utc():
    return datetime.now(timezone.utc).isoformat()


def run():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--circuit", type=Path, required=True)
    ap.add_argument("--output-dir", type=Path, required=True)
    ap.add_argument("--shots", type=int, default=50,
                    help="Total number sampled, before optional shot selection")
    ap.add_argument("--seed", type=int, default=0, help="Stim sampler seed")
    ap.add_argument("--threads", type=int, default=64)
    ap.add_argument("--shot-indices", default=None,
                    help="Comma-separated sample row indices to decode")
    ap.add_argument("--input-samples", type=Path, default=None,
                    help="Reuse samples.npz (detectors and observables arrays)")
    ap.add_argument("--prepare-only", action="store_true")
    ap.add_argument("--save-posteriors", action="store_true")
    ap.add_argument("--check-matrix", type=Path, default=None,
                    help="Explicit H matrix for a verified equivalent detector-basis control")
    ap.add_argument("--observable-matrix", type=Path, default=None)
    ap.add_argument("--error-priors", type=Path, default=None)
    ap.add_argument("--validate-sinter", action="store_true",
                    help="Decode selected shots a second time with stock Sinter API")
    args = ap.parse_args()
    if args.shots <= 0 or args.threads <= 0:
        ap.error("shots and threads must be positive")
    matrix_overrides = (args.check_matrix, args.observable_matrix, args.error_priors)
    if any(p is not None for p in matrix_overrides) and not all(p is not None for p in matrix_overrides):
        ap.error("Provide all three --check-matrix, --observable-matrix and --error-priors together")
    if args.check_matrix is not None and args.validate_sinter:
        ap.error("Stock Sinter rebuilds and may reorder DEM columns; --validate-sinter cannot validate a fixed-column matrix override")
    os.environ["RAYON_NUM_THREADS"] = str(args.threads)
    for name in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"):
        os.environ[name] = "1"

    # These imports must happen after Rayon/BLAS environment configuration.
    import numpy as np
    import relay_bp
    import scipy.sparse as sp
    import stim
    from relay_bp.stim.sinter.check_matrices import CheckMatrices
    from relay_bp.stim import SinterDecoder_RelayBP

    out = args.output_dir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    if (out / "manifest.json").exists():
        raise RuntimeError(f"Refusing to overwrite existing diagnostic run {out}")
    circuit_path = args.circuit.resolve()
    circuit = stim.Circuit.from_file(circuit_path)
    started = time.perf_counter()
    manifest = {
        "status": "preparing", "started_utc": utc(),
        "source_circuit": str(circuit_path), "circuit_sha256": sha256(circuit_path),
        "source_script_sha256": sha256(__file__),
        "argv": sys.argv, "pid": os.getpid(),
        "versions": {k: importlib.metadata.version(k) for k in
                     ("stim", "relay-bp", "numpy", "scipy")},
        "decoder_parameters": PARAMETERS, "parallel": True,
        "threads": args.threads, "sampler_seed": args.seed,
        "sample_batch_size": args.shots,
        "stim_sampling_note": "Seed reproducibility depends on version, machine SIMD, batch size and call sequence.",
        "num_detectors": circuit.num_detectors,
        "num_observables": circuit.num_observables,
        "num_qubits": circuit.num_qubits,
        "original_results_untouched": True,
    }
    write_json(out / "manifest.json", manifest)
    print("Building exact undecomposed DEM and upstream check matrices", flush=True)
    dem = circuit.flattened().detector_error_model(
        decompose_errors=False, allow_gauge_detectors=False,
        ignore_decomposition_failures=False)
    dem.to_file(out / "model.dem")
    if args.check_matrix is None:
        matrices = CheckMatrices.from_dem(dem)
    else:
        # Caller must establish circuit/DEM equivalence. This mode deliberately
        # retains error-variable order, so identical seeded per-variable gamma
        # draws compare only the detector-basis change.
        matrices = CheckMatrices(
            check_matrix=sp.load_npz(args.check_matrix).tocsc().astype(np.uint8),
            observables_matrix=sp.load_npz(args.observable_matrix).tocsc().astype(np.uint8),
            error_priors=np.asarray(np.load(args.error_priors), dtype=np.float64))
        assert matrices.check_matrix.shape[0] == circuit.num_detectors
        assert matrices.observables_matrix.shape[0] == circuit.num_observables
        assert matrices.check_matrix.shape[1] == matrices.observables_matrix.shape[1] == len(matrices.error_priors)
        assert np.all((matrices.error_priors > 0) & (matrices.error_priors < 1))
        assert np.all(matrices.check_matrix.data == 1) and np.all(matrices.observables_matrix.data == 1)
        manifest["matrix_overrides"] = [
            {"path":str(p.resolve()), "sha256":sha256(p)} for p in matrix_overrides]
        manifest["matrix_override_note"] = "Externally verified equivalent detector basis; original error-variable order and priors intentionally preserved."
    H, O, priors = matrices.check_matrix, matrices.observables_matrix, matrices.error_priors
    sp.save_npz(out / "check_matrix.npz", H)
    sp.save_npz(out / "observable_matrix.npz", O)
    np.save(out / "error_priors.npy", priors)
    manifest["matrix_summary"] = {
        "H_shape": H.shape, "O_shape": O.shape,
        "H_nnz": H.nnz, "O_nnz": O.nnz,
        "prior_min": float(priors.min()) if len(priors) else None,
        "prior_max": float(priors.max()) if len(priors) else None,
        "syndrome_bias_active": matrices.syndrome_bias is not None,
        "observable_bias_active": matrices.observables_bias is not None,
        "H_sha256": sha256(out / "check_matrix.npz"),
        "O_sha256": sha256(out / "observable_matrix.npz"),
        "priors_sha256": sha256(out / "error_priors.npy"),
    }

    if args.input_samples is None:
        det, obs = circuit.compile_detector_sampler(seed=args.seed).sample(
            shots=args.shots, bit_packed=False, separate_observables=True)
        det, obs = np.asarray(det, dtype=np.uint8), np.asarray(obs, dtype=np.uint8)
        manifest["sample_source"] = "stim_circuit"
    else:
        with np.load(args.input_samples) as data:
            det, obs = data["detectors"].astype(np.uint8), data["observables"].astype(np.uint8)
        manifest["sample_source"] = str(args.input_samples.resolve())
        manifest["input_samples_sha256"] = sha256(args.input_samples)
        assert len(det) == args.shots, "--shots must equal saved input batch size"
    assert det.shape == (args.shots, circuit.num_detectors)
    assert obs.shape == (args.shots, circuit.num_observables)
    assert np.isin(det, [0, 1]).all() and np.isin(obs, [0, 1]).all()
    det_packed = np.packbits(det, axis=1, bitorder="little")
    obs_packed = np.packbits(obs, axis=1, bitorder="little")
    assert np.array_equal(det, np.unpackbits(det_packed, axis=1, bitorder="little", count=det.shape[1]))
    assert np.array_equal(obs, np.unpackbits(obs_packed, axis=1, bitorder="little", count=obs.shape[1]))
    np.savez_compressed(out / "samples.npz", detectors=det, observables=obs,
                        detectors_packed=det_packed, observables_packed=obs_packed)
    manifest["samples_sha256"] = sha256(out / "samples.npz")
    ids = list(range(args.shots)) if args.shot_indices is None else [int(x) for x in args.shot_indices.split(",")]
    assert ids and len(set(ids)) == len(ids) and min(ids) >= 0 and max(ids) < args.shots
    manifest["decoded_shot_indices"] = ids
    manifest["prepare_seconds"] = time.perf_counter() - started
    manifest["status"] = "prepared" if args.prepare_only else "decoding"
    write_json(out / "manifest.json", manifest)
    if args.prepare_only:
        print(json.dumps(manifest), flush=True)
        return

    syndromes = np.ascontiguousarray(det[ids])
    if matrices.syndrome_bias is not None:
        syndromes = np.ascontiguousarray((syndromes + matrices.syndrome_bias) % 2, dtype=np.uint8)
    decoder = relay_bp.RelayDecoderF64(H, error_priors=priors, **PARAMETERS)
    runner = relay_bp.ObservableDecoderRunner(decoder, O, include_decode_result=True)
    print(f"Decoding {len(ids)} selected shots from {args.shots} saved samples using {args.threads} Rayon threads", flush=True)
    decode_started = time.perf_counter()
    decoded = runner.decode_observables_detailed_batch(
        syndromes, parallel=True, progress_bar=False)
    decode_seconds = time.perf_counter() - decode_started
    rows, corrections, predictions, residuals, reported_dets = [], [], [], [], []
    for slot, (source_id, result) in enumerate(zip(ids, decoded, strict=True)):
        physical = result.physical_decode_result
        assert physical is not None
        correction = np.asarray(physical.decoding, dtype=np.uint8)
        predicted_det = np.asarray(H @ correction, dtype=np.uint8).reshape(-1) % 2
        predicted_obs = np.asarray(O @ correction, dtype=np.uint8).reshape(-1) % 2
        assert np.array_equal(predicted_obs, result.observables)
        assert np.array_equal(predicted_det, physical.decoded_detectors)
        residual = predicted_det ^ syndromes[slot]
        assert bool(result.converged) == bool(physical.success)
        assert bool(result.converged) == (not residual.any())
        if matrices.observables_bias is not None:
            predicted_obs = (predicted_obs + matrices.observables_bias) % 2
        wrong = predicted_obs ^ obs[source_id]
        posterior = np.asarray(physical.posterior_ratios)
        if args.save_posteriors:
            np.save(out / f"posterior_shot_{source_id:04d}.npy", posterior)
        # max_iter is the winning/returned leg budget, not the 80+600*60 relay budget.
        row = {
            "shot_index": source_id, "logical_failure": bool(wrong.any()),
            "wrong_observable_count": int(wrong.sum()),
            "wrong_observable_indices": np.flatnonzero(wrong).tolist(),
            "converged": bool(result.converged), "physical_success": bool(physical.success),
            "syndrome_residual_weight": int(residual.sum()),
            "syndrome_weight": int(syndromes[slot].sum()),
            "correction_weight": int(correction.sum()),
            "total_bp_iterations": int(result.iterations),
            "returned_leg_max_iter": int(physical.max_iter),
            "posterior_nonfinite_count": int((~np.isfinite(posterior)).sum()),
            "posterior_min": float(posterior.min()), "posterior_max": float(posterior.max()),
        }
        rows.append(row)
        corrections.append(correction)
        predictions.append(predicted_obs)
        residuals.append(residual)
        reported_dets.append(physical.decoded_detectors)
    predictions = np.asarray(predictions, dtype=np.uint8)
    predictions_packed = np.packbits(predictions, axis=1, bitorder="little")
    np.savez_compressed(out / "decodings.npz", shot_indices=np.asarray(ids),
                        predicted_observables=predictions,
                        predicted_observables_packed=predictions_packed,
                        corrections_packed=np.packbits(np.asarray(corrections), axis=1, bitorder="little"),
                        correction_num_bits=np.asarray(H.shape[1]),
                        syndrome_residuals=np.asarray(residuals),
                        reported_decoded_detectors=np.asarray(reported_dets))
    write_json(out / "shots.json", rows)
    categories = Counter((row["converged"], row["logical_failure"]) for row in rows)
    summary = {
        "shots_decoded": len(ids), "logical_failures": sum(x["logical_failure"] for x in rows),
        "observed_ler": sum(x["logical_failure"] for x in rows) / len(ids),
        "converged_correct": categories[(True, False)],
        "converged_logical_failure": categories[(True, True)],
        "unconverged_correct_observables": categories[(False, False)],
        "unconverged_logical_failure": categories[(False, True)],
        "syndrome_residual_shots": sum(x["syndrome_residual_weight"] > 0 for x in rows),
        "decode_seconds": decode_seconds,
        "all_returned_H_times_correction_match_reported_detectors": True,
        "all_returned_O_times_correction_match_reported_observables": True,
        "all_convergence_flags_match_zero_syndrome_residual": True,
        "little_endian_input_roundtrip_exact": True,
        "counting_rule": "A logical failure is any observable mismatch; nonconvergence alone is not counted as a logical failure.",
    }
    if args.validate_sinter:
        print("Validating identical selected input through stock packed Sinter adapter", flush=True)
        sinter_parameters = {k: v for k, v in PARAMETERS.items() if k != "seed"}
        compiled = SinterDecoder_RelayBP(**sinter_parameters, parallel=True).compile_decoder_for_dem(dem=dem)
        sinter_started = time.perf_counter()
        packed = compiled.decode_shots_bit_packed(bit_packed_detection_event_data=det_packed[ids])
        assert np.array_equal(packed, predictions_packed)
        summary["stock_sinter_predictions_identical"] = True
        summary["stock_sinter_decode_seconds"] = time.perf_counter() - sinter_started
    else:
        summary["stock_sinter_predictions_identical"] = "not redecoded; use --validate-sinter for independent check"
    write_json(out / "summary.json", summary)
    manifest.update(status="complete", finished_utc=utc(), elapsed_seconds=time.perf_counter() - started,
                    decodings_sha256=sha256(out / "decodings.npz"), summary=summary)
    write_json(out / "manifest.json", manifest)
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    run()
