"""Exact distribution of Appendix A.7 independent elementary faults.

Represent repeated Bernoulli Pauli faults with algebraically equivalent Stim
channels. This preserves the independent-q physical distribution exactly;
it does not assert an identical fault-variable graph inside the decoder.
"""
from collections import Counter
import math

import stim


def write_stim_lossless(circuit, path):
    """Avoid Stim's default six-significant-digit text formatting of rates."""
    def encode(body, indent=''):
        lines = []
        for instruction in body:
            if isinstance(instruction, stim.CircuitRepeatBlock):
                lines.append(f'{indent}REPEAT {instruction.repeat_count} {{')
                lines.extend(encode(instruction.body_copy(), indent+'    '))
                lines.append(indent+'}')
                continue
            line = str(instruction)
            args = instruction.gate_args_copy()
            if args:
                # These benchmark tags contain no parentheses. Preserve the
                # complete Stim-rendered target/tag text, replace only args.
                opening = line.index('(')
                closing = line.index(')', opening)
                line = line[:opening+1] + ', '.join(format(v, '.17g') for v in args) + line[closing:]
            lines.append(indent+line)
        return lines
    text = '\n'.join(encode(circuit)) + '\n'
    assert stim.Circuit(text) == circuit, 'Serialization must preserve exact double-precision gate arguments'
    from pathlib import Path
    Path(path).write_text(text)


def _odd_probability(q, multiplicity):
    return -0.5 * math.expm1(multiplicity * math.log1p(-2 * q))


def convert_to_equal_q(noisy_circuit, p):
    """Return (equivalent circuit, audit) for uniform direct channels at p.

    A reset/readout Pauli flip is 15 independent q events. Each of the three
    idle Paulis has five q events. Each nonidentity two-qubit Pauli has one.
    The output is compact, but distribution-exact including cancellations.
    """
    assert 0 < p < 0.1
    q = p / 15
    flips = _odd_probability(q, 15)
    # Uniform Pauli channels have a single nontrivial Fourier eigenvalue.
    dep1 = -0.75 * math.expm1(10 * math.log1p(-2 * q))
    dep2 = -(15 / 16) * math.expm1(8 * math.log1p(-2 * q))
    counts = Counter()
    sites = Counter()

    def rewrite(circuit, multiplier=1):
        result = stim.Circuit()
        for instruction in circuit:
            if isinstance(instruction, stim.CircuitRepeatBlock):
                result.append(stim.CircuitRepeatBlock(
                    instruction.repeat_count,
                    rewrite(instruction.body_copy(), multiplier * instruction.repeat_count)))
                continue
            name = instruction.name
            if name not in {'X_ERROR', 'Y_ERROR', 'Z_ERROR', 'DEPOLARIZE1', 'DEPOLARIZE2'}:
                if stim.gate_data(name).is_noisy_gate and name not in {'M', 'MX', 'MY', 'MR', 'MRX', 'MRY', 'MPP'}:
                    raise ValueError(f'Unsupported noise instruction: {instruction}')
                if name in {'M', 'MX', 'MY', 'MR', 'MRX', 'MRY', 'MPP'} and instruction.gate_args_copy():
                    raise ValueError('Readout noise must be explicit Pauli errors')
                result.append(instruction)
                continue
            args = instruction.gate_args_copy()
            assert len(args) == 1 and math.isclose(args[0], p, rel_tol=1e-12), (name, args, p)
            targets = instruction.targets_copy()
            site_count = len(targets) // (2 if name == 'DEPOLARIZE2' else 1)
            sites[name] += multiplier * site_count
            counts[name] += multiplier * site_count * 15
            probability = dep2 if name == 'DEPOLARIZE2' else dep1 if name == 'DEPOLARIZE1' else flips
            result.append(name, targets, probability, tag=instruction.tag)
        return result

    converted = rewrite(noisy_circuit)
    audit = {
        'p': p, 'q': q,
        'physical_distribution_matches_independent_q_model': True,
        'elementary_event_count_including_invisible_faults': sum(counts.values()),
        'elementary_events_by_input_channel': dict(counts),
        'channel_sites': dict(sites),
        'equivalent_stim_probabilities': {
            'single_pauli_flip': flips, 'DEPOLARIZE1': dep1, 'DEPOLARIZE2': dep2},
        'note': 'Exact Pauli-channel convolution; Stim DEM may combine faults with identical detector/observable actions. This is not a claim of author-identical decoder columns.',
    }
    return converted, audit


def validate_convolution():
    """Independent finite-group convolution checks all 1/2-qubit outcomes."""
    for p in (0.001, 0.0001):
        q = p / 15
        for width, multiplicity in ((2, 5), (4, 1)):
            size = 1 << width
            distribution = [1.0] + [0.0] * (size - 1)
            for mask in range(1, size):
                for _ in range(multiplicity):
                    distribution = [(1-q)*distribution[i] + q*distribution[i ^ mask]
                                    for i in range(size)]
            probability = -(size-1)/size * math.expm1((size//2)*multiplicity*math.log1p(-2*q))
            expected = [1-probability] + [probability/(size-1)]*(size-1)
            assert max(abs(a-b) for a,b in zip(distribution, expected)) < 1e-13
    return True


if __name__ == '__main__':
    assert validate_convolution()
    print('Independent-fault convolution validated for both noise points.')
