"""Reconstruct a 12-step gross Y1 cycle by the A.5 coloring recipe.

The authors' actual color assignment was not published in the inspected repo.
This file searches only permutations of the optimal bipartite color classes,
retains the existing seven-layer BB schedule and validates signed check flows.
It does not sample or decode. No scientific repository file is changed.
"""
from collections import Counter, defaultdict
from dataclasses import replace
import hashlib
import json
from pathlib import Path
import random
import sys
import time
from types import FunctionType

sys.path.insert(0, '/home/yuehan/bb_code')
import stim
from lightstim.qec_code.BB_code.ppm import native as native_module


def _candidate_layers(native, seed):
    rng = random.Random(seed)
    def shuffled_colors(items):
        colors = native_module._edge_colors(items)
        rng.shuffle(colors)
        return colors
    # Private function globals are copied, never monkeypatched in the module.
    scheduler = FunctionType(native_module._schedule.__code__,
        dict(native_module._schedule.__globals__, _edge_colors=shuffled_colors))
    meta = native.construction
    return scheduler(native.checks, meta.data_sites, meta.bb_check_sites,
                     set(native.edge_qubits), native.bell_pairs)


def build_cycle(native, *, max_candidates=512, cpu_limit_seconds=30):
    """Return (12-slot circuit, ancilla->measurement index, evidence dict)."""
    started = time.process_time()
    if len(native.bell_pairs) != 1:
        raise ValueError('This bounded reconstruction is intended for full-LPU Y1.')
    best = None
    for seed in range(max_candidates):
        layers = _candidate_layers(native, seed)
        if best is None or len(layers) < len(best[1]):
            best = seed, layers
        if len(layers) <= 10:
            break
        if time.process_time() - started >= cpu_limit_seconds:
            break
    seed, layers = best
    if len(layers) > 10:
        raise RuntimeError(f'Bounded coloring search failed: best={len(layers)} layers, seed={seed}')

    # Native back-propagation verifies each positive check on arbitrary inputs.
    syndrome = stim.Circuit()
    for layer in layers:
        for gate in ('CX', 'CY', 'CZ'):
            qs = [q for g,a,b in layer if g == gate for q in (a,b)]
            if qs:
                syndrome.append(gate, qs)
        syndrome.append('TICK')
    syndrome.append('MX', native.syndrome_qubits)
    candidate = replace(native, gate_layers=layers, syndrome_circuit=syndrome)
    candidate.validate()
    assert Counter(e for layer in native.gate_layers for e in layer) == Counter(e for layer in layers for e in layer)

    # Bell preparation is at slot 1; _schedule reserves its two ancillas from
    # other gates in color slot 0 (physical slot 1). Other checks can work then.
    gates = [(1, 'CX', a, b) for a,b in native.bell_pairs]
    gates += [(i+1, g, a, b) for i,layer in enumerate(layers) for g,a,b in layer]
    ancillas = set(native.syndrome_qubits)
    first, last = {}, {}
    for t,g,a,b in gates:
        for q in (a,b):
            if q in ancillas:
                first[q] = min(first.get(q,t),t)
                last[q] = max(last.get(q,t),t)
    events = defaultdict(list)
    for t,g,a,b in gates:
        events[t].append((g,(a,b)))
    for q in native.syndrome_qubits:
        events[first[q]-1].append(('RX' if native.round_reset_bases[q] == 'X' else 'R', (q,)))
        events[last[q]+1].append(('MX',(q,)))
    assert min(events) >= 0 and max(events) <= 11
    out = stim.Circuit()
    record_map = {}
    slot_counts = []
    for t in range(12):
        used = [q for g,qs in events[t] for q in qs]
        assert len(used) == len(set(used)), (t, 'qubit collision')
        gate_counts = {}
        for gate in ('R','RX','CX','CY','CZ','MX'):
            qs = [q for g,qq in events[t] if g == gate for q in qq]
            if not qs:
                continue
            if gate == 'MX':
                for q in qs:
                    record_map[q] = len(record_map)
            out.append(gate, qs)
            gate_counts[gate] = len(qs)//(2 if gate in ('CX','CY','CZ') else 1)
        slot_counts.append(gate_counts)
        out.append('TICK')
    assert set(record_map) == ancillas

    # Each moved R/M crosses only operations on disjoint qubits: all of this
    # ancilla's interactions remain strictly after R and before M. Bell partners
    # are included in first/last. Record order is provided explicitly above.
    # Direct signed tests on the emitted cycle, independent of candidate.validate.
    flows = [stim.Flow(input=ch.pauli,
                       measurements=[record_map[q] for q in ch.ancillas])
             for ch in native.checks]
    assert out.has_all_flows(flows, unsigned=False)
    report = {
        'schedule_kind': 'reconstructed A.5 graph-coloring schedule, not author-identical',
        'seed': seed, 'candidates_checked': seed+1,
        'controlled_P_layers': len(layers), 'physical_slots': 12,
        'measurements': out.num_measurements, 'checks': len(native.checks),
        'all_original_two_qubit_gates_preserved': True,
        'BB_seven_layer_order_and_offsets_preserved_by_scheduler': True,
        'A5_color_phase_order_used': True,
        'Bell_preparation_slot': 1,
        'preparations_as_late_as_possible': True,
        'readouts_as_early_as_possible': True,
        'every_slot_collision_free': True,
        'candidate_native_signed_backprop_checks_passed': True,
        'emitted_cycle_all_signed_check_flows_passed': True,
        'signed_flow_check_method': 'Stim.has_all_flows(unsigned=False), probabilistic algebraic verification; not LER sampling',
        'late_reset_early_readout_equivalence': 'Ancilla reset/readout cross only disjoint-qubit operations. First/last interactions include Bell partner gates; no check ancilla interactions cross a readout. Measurement ordering is explicitly remapped.',
        'limits': ['Exact author edge colors unavailable.',
                   'This verifies the measured checks and local R/M commutation; builder must independently verify the complete signed Y1 instrument and all intended Bell-observable parities.',
                   'No decoder, LER, or circuit-distance claim follows.'],
        'slot_operation_counts': slot_counts,
        'reset_slot_by_ancilla': {str(q):first[q]-1 for q in sorted(ancillas)},
        'measurement_slot_by_ancilla': {str(q):last[q]+1 for q in sorted(ancillas)},
        'ancilla_measurement_indices': {str(q):i for q,i in record_map.items()},
        'cpu_seconds': time.process_time()-started,
        'cycle_sha256': hashlib.sha256(str(out).encode()).hexdigest(),
        'source': 'https://arxiv.org/html/2506.03094#A5',
    }
    return out, record_map, report


if __name__ == '__main__':
    from lightstim.qec_code.BB_code.ppm.shift import build_tour_de_gross_code
    code = build_tour_de_gross_code()
    offsets = {'L':(0,1),'R':(1,0),'X':(0,0),'Z':(1,1)}
    maps = {s:{(s,i,j):code.index_map[(2*i+dx,2*j+dy)] for i in range(12) for j in range(6)} for s,(dx,dy) in offsets.items()}
    n = native_module.build_native_measurement('Y','I', data_index=maps['L']|maps['R'], bb_check_indices=maps['X']|maps['Z'], ancilla_start=288)
    c,record_map,report = build_cycle(n)
    folder = Path(__file__).resolve().parent
    (folder/'native_Y1_12step_cycle.stim').write_text(str(c)+'\n')
    (folder/'native_Y1_12step_schedule.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if not k.endswith('_by_ancilla') and k not in ('ancilla_measurement_indices','slot_operation_counts')},indent=2))
