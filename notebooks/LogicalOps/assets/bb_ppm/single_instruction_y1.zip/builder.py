#!/usr/bin/env python3
"""One gross Y1 instruction with ideal encoded input and 23 action observables.

No sampling or decoding is performed here. Bulk detectors are the XOR of the
same merged check in adjacent cycles. Only transition-boundary constraints use
linear algebra; reference logical qubits are never exposed to physical noise.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import time

for variable in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[variable] = "1"

REPO = Path("/home/yuehan/bb_code")
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(REPO))
import numpy as np
import stim
from lightstim.ir.qec_system import QECSystem
from lightstim.noise.config import NoiseConfig
from lightstim.noise.injector import NoiseInjector
from lightstim.qec_code.BB_code import BBCodeExtractionBlock
from lightstim.qec_code.BB_code.ppm.native import build_native_measurement
from lightstim.qec_code.BB_code.ppm.shift import build_tour_de_gross_code


def bits(mask):
    while mask:
        low = mask & -mask
        yield low.bit_length() - 1
        mask ^= low


def mask_of(indices):
    value = 0
    for index in indices:
        value ^= 1 << int(index)
    return value


def pauli_mask(pauli):
    x, z = pauli.to_numpy()
    return mask_of(np.flatnonzero(np.concatenate((x, z))))


def insert_basis(value, basis):
    while value:
        pivot = value.bit_length() - 1
        if pivot not in basis:
            basis[pivot] = value
            return value
        value ^= basis[pivot]
    return 0


def rank(rows):
    basis = {}
    for row in rows:
        insert_basis(row, basis)
    return len(basis)


def physical_pauli(support, size):
    result = stim.PauliString(size)
    for qubit, letter in support.items():
        result[qubit] = letter
    return result


def noiseless(circuit):
    result = stim.Circuit()
    for instruction in circuit.flattened():
        result.append(instruction.name, instruction.targets_copy(),
                      instruction.gate_args_copy(), tag="noiseless")
    return result


def end_moment(circuit, *, ideal=False):
    if len(circuit) and circuit[-1].name != "TICK":
        circuit.append("TICK", tag="noiseless" if ideal else "")


def mpp(pauli):
    targets = []
    for qubit in pauli.pauli_indices():
        if targets:
            targets.append(stim.target_combiner())
        targets.append({1:stim.target_x, 2:stim.target_y, 3:stim.target_z}[pauli[qubit]](qubit))
    assert targets
    if pauli.sign == -1:
        targets[0] = stim.target_inv(targets[0])
    assert pauli.sign in (1, -1)
    return targets


def objects():
    code = build_tour_de_gross_code()
    offsets = {"L":(0,1), "R":(1,0), "X":(0,0), "Z":(1,1)}
    maps = {label:{(label,x,y):code.index_map[(2*x+dx,2*y+dy)]
                   for x in range(12) for y in range(6)}
            for label,(dx,dy) in offsets.items()}
    native = build_native_measurement("Y", "I", data_index=maps["L"]|maps["R"],
                                      bb_check_indices=maps["X"]|maps["Z"], ancilla_start=288)
    system = QECSystem()
    system.add_patch(code, name="bb")
    final_cycle = noiseless(BBCodeExtractionBlock(system).circuit)
    return code, native, final_cycle


def encoded_preparation(code, native, *, measured_eigenstate):
    """Actual: +Y1 and 11 Bell pairs. Detector reference: all 12 Bell pairs."""
    logical_indices = range(1,12) if measured_eigenstate else range(12)
    size = native.num_qubits + len(logical_indices)
    stabilizers = [physical_pauli(record["pauli"], size) for record in code.stabilizers]
    xs = [physical_pauli(record["pauli"], size) for record in code.logical_ops if record["type"] == "X"]
    zs = [physical_pauli(record["pauli"], size) for record in code.logical_ops if record["type"] == "Z"]
    target = 1j * xs[0] * zs[0]
    assert target[:native.num_qubits] == native.target_pauli
    if measured_eigenstate:
        stabilizers.append(target)
    bell_checks = []
    for reference_offset, logical_index in enumerate(logical_indices):
        for basis, operators in (("X", xs), ("Z", zs)):
            pauli = operators[logical_index].copy()
            pauli[native.num_qubits + reference_offset] = basis
            stabilizers.append(pauli)
            bell_checks.append((f"{basis}{logical_index+1}_data_reference", pauli))
    # Fix unused physical auxiliaries to |0>; they are explicitly reset by
    # each native measurement before use. References have no noise locations.
    for qubit in sorted(set(range(native.num_qubits)) - set(code.data_indices)):
        stabilizers.append(physical_pauli({qubit:"Z"}, size))
    tableau = stim.Tableau.from_stabilizers(stabilizers, allow_redundant=True)
    circuit = stim.Circuit()
    circuit.append("R", range(size), tag="noiseless")
    circuit += noiseless(tableau.to_circuit())
    end_moment(circuit, ideal=True)
    assert circuit.num_measurements == 0
    return circuit, bell_checks


def measurement_order(cycle):
    result = {}
    offset = 0
    for instruction in cycle.flattened():
        if instruction.name in ("M", "MX", "MY"):
            for target in instruction.targets_copy():
                assert target.value not in result
                result[target.value] = offset
                offset += 1
        else:
            assert not stim.gate_data(instruction.name).produces_measurements
    return result


def get_cycle(native, schedule):
    if schedule == "local":
        cycle = native.round_circuit
        end_moment(cycle)
        mapping = measurement_order(cycle)
        report = {"name":"local original graph-coloring schedule",
                  "matches_paper_12_step_duration":False,
                  "controlled_pauli_layers":len(native.gate_layers),
                  "ticks_per_cycle":sum(i.name == "TICK" for i in cycle)}
    else:
        path = HERE / "scheduler.py"
        if not path.exists():
            raise FileNotFoundError("Requested 12-step scheduler is not yet available")
        spec = importlib.util.spec_from_file_location("single_instruction_scheduler", path)
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
        cycle, mapping, report = module.build_cycle(native)
        end_moment(cycle)
        assert mapping == measurement_order(cycle)
    assert set(mapping) == set(native.syndrome_qubits)
    assert cycle.num_measurements == len(native.syndrome_qubits)
    return cycle, mapping, report


def build_body(native, cycle, final_cycle, rounds):
    """No preparation/readout of logical references and no annotations."""
    result = native.prepare_circuit.copy()
    starts = []
    for cycle_index in range(rounds):
        starts.append(result.num_measurements)
        # Edge preparation shares the first check-reset slot; edge gauge-out
        # shares the last check-readout slot. The 12-slot scheduler verifies
        # no edge interaction occurs in either shared boundary slot.
        result += cycle[:-1] if cycle_index == rounds-1 and cycle[-1].name == "TICK" else cycle
        if cycle_index != rounds-1:
            end_moment(result)
    gauge_start = result.num_measurements
    result += native.gaugeout_circuit
    # Close the noisy final readout moment before ideal frame bookkeeping.
    # Otherwise NoiseInjector would count feedback data targets as operated
    # and accidentally omit their final-slot idle channels.
    end_moment(result)
    for correction in native.frame_corrections:
        for record_offset in correction.edge_result_indices:
            record = gauge_start + record_offset
            for letter in "XYZ":
                qubits = sorted(q for q,p in correction.pauli.items() if p == letter)
                if qubits:
                    targets = [t for q in qubits for t in
                               (stim.target_rec(record-result.num_measurements), q)]
                    result.append("C"+letter, targets, tag="noiseless")
    end_moment(result, ideal=True)
    final_start = result.num_measurements
    result += final_cycle
    end_moment(result, ideal=True)
    return result, {"cycle_starts":starts, "gauge_start":gauge_start,
                    "final_stabilizer_start":final_start,
                    "total_measurements":result.num_measurements}


def first_boundary_constraints(code, native, mapping):
    """Intersection of merged checks with code stabilizers and prepared edge Z.

    Deliberately omit the prepared logical +Y1. Its parity is an observable,
    not a detector. This avoids obtaining a free measurement-outcome oracle.
    """
    initial_basis = {}
    for record in code.stabilizers:
        insert_basis(pauli_mask(physical_pauli(record["pauli"], native.num_qubits)), initial_basis)
    for qubit in native.edge_qubits:
        insert_basis(pauli_mask(physical_pauli({qubit:"Z"}, native.num_qubits)), initial_basis)
    unknown = {}
    constraints = []
    for check in native.checks:
        pauli = pauli_mask(check.pauli)
        for pivot in sorted(initial_basis, reverse=True):
            if (pauli >> pivot) & 1:
                pauli ^= initial_basis[pivot]
        record_mask = mask_of(mapping[q] for q in check.ancillas)
        while pauli:
            pivot = pauli.bit_length()-1
            if pivot not in unknown:
                unknown[pivot] = (pauli, record_mask)
                break
            other, records = unknown[pivot]
            pauli ^= other
            record_mask ^= records
        if not pauli and record_mask:
            constraints.append(record_mask)
    return constraints


def measurement_only_flows(circuit):
    """Eliminate quantum endpoints from exact stabilizer-flow generators."""
    endpoints = {}
    relations = []
    flows = circuit.flow_generators()
    for flow in flows:
        assert flow.input_copy().weight == 0, "Preparation must erase every quantum input"
        pauli = pauli_mask(flow.output_copy())
        records = mask_of(flow.measurements_copy())
        while pauli:
            pivot = pauli.bit_length()-1
            if pivot not in endpoints:
                endpoints[pivot] = (pauli, records)
                break
            other, parity = endpoints[pivot]
            pauli ^= other
            records ^= parity
        if not pauli and records:
            relations.append(records)
    return relations, len(flows)


def build_detectors(code, native, cycle, mapping, final_cycle, body_metadata):
    first = first_boundary_constraints(code, native, mapping)
    reference_preparation, _ = encoded_preparation(code, native, measured_eigenstate=False)
    single_body, single = build_body(native, cycle, final_cycle, 1)
    # Only one native cycle is used in this transition calculation. Thus its
    # complement cannot produce rows spanning the full ten-cycle history.
    relations, flow_count = measurement_only_flows(reference_preparation + single_body)
    known = {}
    for row in first:
        insert_basis(row, known)
    final_local = []
    for row in relations:
        reduced = insert_basis(row, known)
        if reduced:
            final_local.append(reduced)
    assert rank(first+relations) == rank(relations), "Initial boundary is not implied by physical flows"
    assert len(known) == (reference_preparation+single_body).count_determined_measurements()
    shift = body_metadata["cycle_starts"][-1]
    rows = [(row, {"kind":"initial_boundary", "cycle":0}) for row in first]
    for cycle_index in range(1, len(body_metadata["cycle_starts"])):
        previous = body_metadata["cycle_starts"][cycle_index-1]
        current = body_metadata["cycle_starts"][cycle_index]
        for check in native.checks:
            parity = mask_of(mapping[q] for q in check.ancillas)
            rows.append(((parity << previous) ^ (parity << current),
                         {"kind":"adjacent_cycle_same_check", "cycle":cycle_index,
                          "check":check.name, "check_kind":check.kind}))
    rows += [(row << shift, {"kind":"final_boundary", "cycle":len(body_metadata["cycle_starts"])-1})
             for row in final_local]
    return rows, {"first_boundary_rows":len(first), "final_boundary_rows":len(final_local),
                  "bulk_rows":(len(body_metadata["cycle_starts"])-1)*len(native.checks),
                  "one_cycle_measurement_relation_rank":len(known),
                  "one_cycle_flow_generators":flow_count,
                  "boundary_method":"Initial code-stabilizer/edge-Z intersection. Complement from exact one-cycle stabilizer-flow elimination; final boundary mapped only to last cycle, gauge-out and final ideal BB checks.",
                  "bulk_method":"One parity difference for every native check in each adjacent pair of cycles; Bell halves are combined into the check parity.",
                  "logical_Y1_excluded_from_detector_initial_constraints":True}


def validate_cycle_operators(native, cycle, mapping):
    """Check actual reset/gate/readout operations against all signed checks."""
    flows = [stim.Flow(input=check.pauli, measurements=[mapping[q] for q in check.ancillas])
             for check in native.checks]
    assert cycle.has_all_flows(flows, unsigned=False), "Cycle does not measure its advertised signed checks"
    assert not cycle.has_flow(stim.Flow(input=-native.checks[0].pauli,
                                       measurements=[mapping[q] for q in native.checks[0].ancillas]), unsigned=False)
    return {"all_merged_signed_check_flows_passed":True, "wrong_sign_negative_control_rejected":True,
            "flow_validation_scope":"Stim has_all_flows(unsigned=False), randomized stabilizer algebra; no physical samples.",
            "check_count":len(flows)}


def build(*, rounds=10, schedule="local"):
    started = time.process_time()
    code, native, final_cycle = objects()
    cycle, mapping, schedule_report = get_cycle(native, schedule)
    cycle_validation = validate_cycle_operators(native, cycle, mapping)
    preparation, bells = encoded_preparation(code, native, measured_eigenstate=True)
    body, body_meta = build_body(native, cycle, final_cycle, rounds)
    detector_rows, detector_report = build_detectors(code, native, cycle, mapping, final_cycle, body_meta)
    clean = preparation + body
    obs_rows = []
    target_records = [body_meta["cycle_starts"][-1] + mapping[native.syndrome_qubits[index]]
                      for index in native.outcome_parity]
    obs_rows.append((mask_of(target_records), "measured_+Y1_protocol_outcome"))
    # Verify measurement and post-measurement target sign directly on the
    # physical body, independent of the prepared +Y1 eigenvalue.
    assert body.has_flow(stim.Flow(input=native.target_pauli, measurements=target_records), unsigned=False)
    assert body.has_flow(stim.Flow(output=native.target_pauli, measurements=target_records), unsigned=False)
    assert not body.has_flow(stim.Flow(input=-native.target_pauli, measurements=target_records), unsigned=False)
    # An arbitrary encoded input has a random Y1 outcome. The detector-only
    # circuit must remain deterministic, while promoting Y1 to an observable
    # without preparing its eigenstate must fail strict determinism. Thus the
    # boundary constraints cannot quietly supply its value as a free syndrome.
    unknown_preparation, _ = encoded_preparation(code, native, measured_eigenstate=False)
    unknown_target = unknown_preparation + body
    for row, _ in detector_rows:
        unknown_target.append("DETECTOR", [stim.target_rec(j-unknown_target.num_measurements) for j in bits(row)])
    assert unknown_target.detector_error_model(allow_gauge_detectors=False).num_errors == 0
    unknown_target.append("OBSERVABLE_INCLUDE", [stim.target_rec(j-unknown_target.num_measurements) for j in target_records], [0])
    try:
        unknown_target.detector_error_model(allow_gauge_detectors=False)
    except ValueError as error:
        assert "non-deterministic observables" in str(error)
    else:
        raise AssertionError("The unknown-input Y1 outcome was spuriously deterministic")
    for label, pauli in bells:
        record = clean.num_measurements
        clean.append("MPP", mpp(pauli), tag="noiseless")
        obs_rows.append((1 << record, label))
    end_moment(clean, ideal=True)
    for index, (row, provenance) in enumerate(detector_rows):
        clean.append("DETECTOR", [stim.target_rec(j-clean.num_measurements) for j in bits(row)],
                     [index, provenance["cycle"], {"initial_boundary":0,"adjacent_cycle_same_check":1,"final_boundary":2}[provenance["kind"]]])
    for index, (row, _) in enumerate(obs_rows):
        clean.append("OBSERVABLE_INCLUDE", [stim.target_rec(j-clean.num_measurements) for j in bits(row)], [index])
    assert len(obs_rows) == clean.num_observables == 23
    assert clean.detector_error_model(allow_gauge_detectors=False).num_errors == 0
    determinant_rank = rank([row for row,_ in detector_rows])
    combined_rank = rank([row for row,_ in detector_rows] + [row for row,_ in obs_rows])
    determined = clean.count_determined_measurements()
    assert combined_rank == determined
    assert combined_rank-determinant_rank == 23
    metadata = {
        "status":"complete", "physical_sampling_calls":0, "decoder_calls":0,
        "code":"gross [[144,12,12]]", "logical_basis":"tour_de_gross", "instruction":"+Y1",
        "native_measurement_instructions":1, "shift_instructions":0, "merged_cycles":rounds,
        "physical_qubits_in_noise_universe":native.num_qubits,
        "noiseless_reference_qubits":list(range(native.num_qubits, clean.num_qubits)),
        "total_qubits_including_references":clean.num_qubits,
        "boundary_definition":"Ideal encoded +Y1, with logical qubits2..12 Bell-paired to noiseless references; final noise-free original BB syndrome cycle and ideal logical Bell readout.",
        "observable_definition":"Observable0 is the signed native measurement outcome on known +Y1. Observable1..22 are X/Z logical Bell parities for the other11 logical qubits. No independent ideal final Y1 measurement is supplied to the decoder.",
        "observable_names":[label for _,label in obs_rows], "num_observables":23,
        "observables":[{"index":i,"label":label,"absolute_records":list(bits(row))} for i,(row,label) in enumerate(obs_rows)],
        "detectors":dict(detector_report, rows=len(detector_rows), rank=determinant_rank,
                         combined_detector_observable_rank=combined_rank, determined_measurements=determined,
                         deterministic_parity_space_complete_for_fixed_circuit=True,
                         strict_clean_dem_deterministic=True),
        "schedule":schedule_report, "signed_cycle_validation":cycle_validation,
        "target_signed_instrument_validation":{
            "physical_body_input_Y1_equals_protocol_record":True,
            "physical_body_output_Y1_equals_protocol_record":True,
            "wrong_target_sign_rejected":True,
            "detectors_remain_deterministic_for_arbitrary_12_logical_Bell_input":True,
            "unknown_input_target_observable_rejected_as_nondeterministic":True,
            "no_extra_ideal_Y1_measurement_or_outcome_oracle":True,
            "scope":"Signed Stim algebra checks and strict deterministic DEM; no physical samples."},
        "body_measurement_offsets":body_meta,
        "noisy_body_ticks":sum(i.name == "TICK" and i.tag != "noiseless" for i in body),
        "total_ticks":sum(i.name == "TICK" for i in clean),
        "unmatched_aspects":[
            "Matching23 observable semantics and ideal boundaries does not establish the authors exact edge-color assignment or complete physical schedule.",
            "Boundary detector basis comes from explicit code and one-cycle flow algebra; the authors exact H row presentation is unavailable. Bulk uses their adjacent-cycle same-check prescription.",
            "Compact equal-q Pauli convolution can match the A.7 physical fault distribution, but merged DEM columns need not match the paper expanded equal-q decoder graph.",
            "Modern Relay parameter names and implementation are independently audited; exact equivalence to the authors historical backend remains unproved.",
            "Fifty shots can diagnose large failure/nonconvergence rates but cannot establish a true LER of1e-5 or lower."
        ],
        "source_sha256":{str(path.relative_to(REPO)):hashlib.sha256(path.read_bytes()).hexdigest()
                         for path in (REPO/"lightstim/qec_code/BB_code/ppm/native.py", REPO/"lightstim/qec_code/BB_code/SE_block.py")},
        "builder_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "build_cpu_seconds":time.process_time()-started,
    }
    return clean, metadata


def write_artifacts(output, *, rounds=10, schedule="local", probabilities=(0.001, 0.0001)):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    clean, metadata = build(rounds=rounds, schedule=schedule)
    clean.to_file(output / "clean.stim")
    metadata["clean_sha256"] = hashlib.sha256((output / "clean.stim").read_bytes()).hexdigest()
    metadata["noise_cases"] = []
    from paper_noise import convert_to_equal_q, validate_convolution, write_stim_lossless
    assert validate_convolution()
    for p in probabilities:
        config = NoiseConfig(p_1q=p, p_2q=p, p_meas=p, p_reset=p, p_idle=p)
        direct = NoiseInjector.from_circuit_level_with_idling(config,
                    list(range(metadata["physical_qubits_in_noise_universe"]))).inject_noise(clean)
        assert direct.without_noise() == clean
        for instruction in direct.flattened():
            if instruction.name in {"X_ERROR", "Y_ERROR", "Z_ERROR", "DEPOLARIZE1", "DEPOLARIZE2"}:
                assert all(t.value < metadata["physical_qubits_in_noise_universe"] for t in instruction.targets_copy())
        equal_q, audit = convert_to_equal_q(direct, p)
        direct_path = output / f"direct_noisy_p_{p:g}.stim"
        paper_path = output / f"noisy_p_{p:g}.stim"
        direct.to_file(direct_path)
        write_stim_lossless(equal_q, paper_path)
        dem = equal_q.detector_error_model(allow_gauge_detectors=False)
        case = dict(p=p, circuit=paper_path.name, direct_circuit=direct_path.name,
                    sha256=hashlib.sha256(paper_path.read_bytes()).hexdigest(),
                    direct_sha256=hashlib.sha256(direct_path.read_bytes()).hexdigest(),
                    num_dem_errors=dem.num_errors, num_detectors=dem.num_detectors,
                    num_observables=dem.num_observables, paper_noise=audit,
                    noiseless_reference_noise_exclusion_verified=True)
        metadata["noise_cases"].append(case)
    (output / "build_manifest.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2)+"\n")
    print(json.dumps({key:metadata[key] for key in ("status", "instruction", "merged_cycles", "num_observables", "detectors", "schedule", "build_cpu_seconds")}, indent=2),flush=True)
    return metadata


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=HERE/"circuits_local")
    parser.add_argument("--schedule", choices=("local", "paper12"), default="local")
    parser.add_argument("--rounds", type=int, default=10)
    parser.add_argument("--p", type=float, action="append")
    args = parser.parse_args()
    write_artifacts(args.output_dir, rounds=args.rounds, schedule=args.schedule,
                    probabilities=args.p or (0.001,0.0001))


if __name__ == "__main__":
    main()
