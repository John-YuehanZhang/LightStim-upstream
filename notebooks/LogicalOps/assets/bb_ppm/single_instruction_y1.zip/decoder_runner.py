#!/usr/bin/env python3
"""Run exactly 50 shots with the audited modern gross Relay-BP configuration.

The input Stim circuit must already contain the intended physical noise and
single-instruction boundaries/observables. --p records its intended physical
error probability; it does not insert or change noise. Invoke the two noise
points sequentially. A directory-local lock prevents simultaneous invocations
of this wrapper from each allocating a 64-thread Rayon pool.

Example:
  python decoder_runner.py --circuit native_p001.stim --p 0.001 \
      --output-dir results/native_p001

No alternate decoder, clipping, arbitrary matrix override, shot selection, or
changed iteration budget is exposed. --expanded-equal-q explicitly replaces
merged mechanisms with verified identical columns at q=p/15. This is a graph
comparison, not a claim to recover the authors' exact historical column order.
--prepare-only saves all 50 samples and matrices without decoding, permitting
the previously audited checkpointed runner to resume expensive work.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import fcntl
import hashlib
import importlib.metadata
import json
import math
import os
from pathlib import Path
import runpy
import sys


AUDITED_RUNNER = Path('/home/yuehan/bb_ppm_results/causal_diagnostics/decoder/diagnose_decoder.py')
AUDITED_SHA256 = 'd2e8e7d9cd2d30e534f14ba16b6001f94272fb3905bab1913016a6befd6b3224'
MODERN_PARAMETERS = dict(
    alpha=1.0, gamma0=0.125, pre_iter=80, num_sets=600, set_max_iter=60,
    gamma_dist_interval=(-0.24, 0.66), stop_nconv=5,
    stopping_criterion='nconv', logging=False, seed=0,
)
LEGACY_TABLE7 = dict(
    selected_row='other gross', gamma=0.79, rng_width=0.45,
    ewainit_discount_factor=0.875, num_sets=600, pre_iter=80,
    set_num_iters=60, stop_nconv=5, max_iter=60, ms_scaling_factor=1,
)
HISTORICAL_CAVEAT = (
    'The modern gross parameters are unchanged from the audited prior runs. '
    'Exact equivalence to the historical Table 7 discount/RNG implementation '
    'is unproven; its original executable backend was not obtained. '
    'The paper elementary equal-q fault graph is not assumed identical to '
    'the merged Stim DEM / public Relay adapter graph.'
)


def preflight(circuit_path, out, p, *, expanded_equal_q=False):
    """Check every DEM signature and the public adapter, without sampling."""
    import numpy as np
    import scipy.sparse as sp
    import stim
    from relay_bp.stim.sinter.check_matrices import CheckMatrices

    circuit = stim.Circuit.from_file(circuit_path)
    dem = circuit.flattened().detector_error_model(
        decompose_errors=False, allow_gauge_detectors=False,
        ignore_decomposition_failures=False)
    grouped = {}
    error_instructions = 0
    collisions = []
    q = p / 15
    log_single_parity = math.log1p(-2*q)
    visible_elementary_faults = 0
    max_integer_residual = 0.0
    multiplicity_failures = []
    for instruction in dem.flattened():
        if instruction.type != 'error':
            continue
        probability = float(instruction.args_copy()[0])
        if probability == 0:
            continue
        error_instructions += 1
        if not 0 < probability < 0.5:
            raise RuntimeError('Expected nonzero equal-q merged probabilities below 1/2.')
        multiplicity = math.log1p(-2*probability) / log_single_parity
        nearest = round(multiplicity)
        integer_residual = abs(multiplicity-nearest)
        max_integer_residual = max(max_integer_residual, integer_residual)
        if nearest < 1 or integer_residual > 1e-6:
            multiplicity_failures.append(dict(error_index=error_instructions-1,
                                             probability=probability, multiplicity=multiplicity))
        visible_elementary_faults += nearest
        detectors, observables = set(), set()
        for target in instruction.targets_copy():
            if target.is_relative_detector_id():
                detectors.symmetric_difference_update((target.val,))
            elif target.is_logical_observable_id():
                observables.symmetric_difference_update((target.val,))
            elif target.is_separator():
                raise RuntimeError('Unexpected decomposed error in the undecomposed DEM.')
        key, action = tuple(sorted(detectors)), tuple(sorted(observables))
        if key in grouped:
            previous_action, previous_probability, count = grouped[key]
            if action != previous_action:
                collisions.append(dict(detectors=key, first_observables=previous_action,
                                       conflicting_observables=action))
            probability = previous_probability * (1-probability) + probability * (1-previous_probability)
            grouped[key] = (previous_action, probability, count+1)
        else:
            grouped[key] = (action, probability, 1)
    audit = dict(
        source_circuit=os.path.relpath(circuit_path, out),
        circuit_sha256=hashlib.sha256(circuit_path.read_bytes()).hexdigest(),
        circuit_detectors=circuit.num_detectors,
        circuit_observables=circuit.num_observables,
        raw_dem_nonzero_error_instructions=error_instructions,
        unique_detector_signatures=len(grouped),
        same_detector_different_observable_collisions=collisions,
        duplicate_signature_groups=sum(item[2] > 1 for item in grouped.values()),
        physical_error_probability=p, elementary_q=q,
        inferred_visible_elementary_fault_count=visible_elementary_faults,
        multiplicity_max_distance_from_integer=max_integer_residual,
        multiplicity_integer_tolerance=1e-6,
        multiplicity_failure_count=len(multiplicity_failures),
        multiplicity_failures=multiplicity_failures[:20],
        multiplicity_failure_examples_limit=20,
        multiplicity_scope='For each nonzero raw DEM error P, infer m=log1p(-2P)/log1p(-2q); count excludes elementary faults with no detector or observable action. This does not reveal whether the historical decoder kept duplicate fault columns.',
        prior_combine_rule='p_new = p_old*(1-p) + p*(1-p_old)',
        representation_caveat=HISTORICAL_CAVEAT,
    )
    audit_path = out / 'decoder_representation_audit.json'
    if multiplicity_failures:
        audit['status'] = 'rejected_noninteger_equal_q_multiplicity'
        audit_path.write_text(json.dumps(audit, indent=2) + '\n')
        raise RuntimeError('DEM priors do not match integer multiplicities of independent q=p/15 faults.')
    if collisions:
        audit['status'] = 'rejected_logical_signature_collision'
        audit_path.write_text(json.dumps(audit, indent=2) + '\n')
        raise RuntimeError('Same-D/different-O collision would lose logical information in the public adapter.')
    matrices = CheckMatrices.from_dem(dem)
    if matrices.syndrome_bias is not None or matrices.observables_bias is not None:
        raise RuntimeError('Unexpected deterministic-prior bias; requires a separate adapter audit.')
    H, O, priors = matrices.check_matrix.tocsc(), matrices.observables_matrix.tocsc(), matrices.error_priors
    assert H.shape[0] == circuit.num_detectors and O.shape[0] == circuit.num_observables
    assert H.shape[1] == O.shape[1] == len(priors) == len(grouped)
    assert np.all(H.data == 1) and np.all(O.data == 1)
    seen = set()
    maximum_prior_difference = 0.0
    for column, probability in enumerate(priors):
        key = tuple(sorted(int(i) for i in H.indices[H.indptr[column]:H.indptr[column+1]]))
        action = tuple(sorted(int(i) for i in O.indices[O.indptr[column]:O.indptr[column+1]]))
        assert key not in seen and key in grouped
        seen.add(key)
        expected_action, expected_probability, _ = grouped[key]
        assert action == expected_action
        assert np.isclose(probability, expected_probability, rtol=1e-12, atol=1e-15)
        maximum_prior_difference = max(maximum_prior_difference, abs(float(probability)-expected_probability))
    assert seen == set(grouped)
    audit.update(status='passed', adapter_H_shape=H.shape, adapter_O_shape=O.shape,
                 adapter_H_nnz=H.nnz, adapter_O_nnz=O.nnz,
                 exact_signature_and_parity_prior_correspondence=True,
                 maximum_prior_absolute_difference=maximum_prior_difference,
                 sampler_calls=0, decoder_calls=0)
    if expanded_equal_q:
        multiplicities_float = np.log1p(-2*np.asarray(priors)) / log_single_parity
        multiplicities = np.rint(multiplicities_float).astype(np.int64)
        assert np.all(multiplicities > 0)
        assert np.max(np.abs(multiplicities_float-multiplicities)) <= 1e-6
        source_columns = np.repeat(np.arange(H.shape[1], dtype=np.int64), multiplicities)
        expanded_H = H[:, source_columns].tocsc()
        expanded_O = O[:, source_columns].tocsc()
        expanded_priors = np.full(len(source_columns), q, dtype=np.float64)
        collapsed_priors = -0.5*np.expm1(multiplicities*log_single_parity)
        assert np.allclose(collapsed_priors, priors, rtol=1e-10, atol=1e-14)
        assert expanded_H.shape[1] == expanded_O.shape[1] == len(expanded_priors)
        assert len(source_columns) == visible_elementary_faults
        assert np.array_equal(np.bincount(source_columns, minlength=H.shape[1]), multiplicities)
        assert expanded_H.nnz == int(np.dot(np.diff(H.indptr), multiplicities))
        assert expanded_O.nnz == int(np.dot(np.diff(O.indptr), multiplicities))
        folder = out / 'verified_expanded_graph'
        folder.mkdir(exist_ok=True)
        sp.save_npz(folder / 'check_matrix.npz', expanded_H)
        sp.save_npz(folder / 'observable_matrix.npz', expanded_O)
        np.save(folder / 'error_priors.npy', expanded_priors)
        np.save(folder / 'expanded_to_merged_columns.npy', source_columns)
        np.save(folder / 'merged_column_multiplicities.npy', multiplicities)
        files = {name: dict(path=os.path.relpath(folder/name, out),
                           sha256=hashlib.sha256((folder/name).read_bytes()).hexdigest())
                 for name in ('check_matrix.npz', 'observable_matrix.npz', 'error_priors.npy',
                              'expanded_to_merged_columns.npy', 'merged_column_multiplicities.npy')}
        audit['expanded_equal_q'] = dict(
            enabled=True, check_shape=expanded_H.shape, observable_shape=expanded_O.shape,
            check_nnz=expanded_H.nnz, observable_nnz=expanded_O.nnz,
            all_priors_equal_q=True, files=files,
            column_order='Each public-adapter merged column is repeated m times contiguously, retaining the original merged-column order.',
            distribution_equivalence='Repeated equal-action independent q faults combine by parity to each original merged prior, checked numerically for every column.',
            max_collapsed_prior_absolute_difference=float(np.max(np.abs(collapsed_priors-priors))),
            omitted_zero_action_faults='Original physical faults invisible to both H and O are absent from the Stim DEM and are not reconstructed. Their positions and the author historical column order are unknown.',
            historical_decoder_graph_equivalence_proven=False,
        )
    else:
        audit['expanded_equal_q'] = dict(enabled=False)
    audit_path.write_text(json.dumps(audit, indent=2) + '\n')
    return audit


def independently_check_saved_results(out):
    import numpy as np
    import scipy.sparse as sp
    H = sp.load_npz(out / 'check_matrix.npz')
    O = sp.load_npz(out / 'observable_matrix.npz')
    samples = dict(np.load(out / 'samples.npz'))
    decoded = dict(np.load(out / 'decodings.npz'))
    rows = json.loads((out / 'shots.json').read_text())
    assert decoded['shot_indices'].tolist() == list(range(50))
    assert [row['shot_index'] for row in rows] == list(range(50))
    for label in ('detectors', 'observables'):
        assert np.array_equal(samples[label], np.unpackbits(samples[label+'_packed'],
            axis=1, bitorder='little', count=samples[label].shape[1]))
    correction = np.unpackbits(decoded['corrections_packed'], axis=1,
                               bitorder='little', count=H.shape[1])
    predicted_det = np.asarray((H @ correction.T).T, dtype=np.uint8) % 2
    predicted_obs = np.asarray((O @ correction.T).T, dtype=np.uint8) % 2
    residual = predicted_det ^ samples['detectors']
    assert np.array_equal(residual, decoded['syndrome_residuals'])
    assert np.array_equal(predicted_det, decoded['reported_decoded_detectors'])
    assert np.array_equal(predicted_obs, decoded['predicted_observables'])
    assert np.array_equal(np.packbits(predicted_obs, axis=1, bitorder='little'),
                          decoded['predicted_observables_packed'])
    for index, row in enumerate(rows):
        assert row['converged'] == row['physical_success'] == (not residual[index].any())
        assert row['logical_failure'] == bool(np.any(predicted_obs[index] ^ samples['observables'][index]))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--circuit', type=Path, required=True)
    parser.add_argument('--p', type=float, choices=(0.001, 0.0001), required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--expanded-equal-q', action='store_true',
                        help='Use verified repeated H/O columns with prior q=p/15; explicit alternative graph')
    parser.add_argument('--input-samples', type=Path,
                        help='Reuse an existing 50-shot samples.npz verbatim instead of sampling')
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument('--preflight-only', action='store_true',
                      help='Build/audit the DEM and graph only; no sampling or decoding')
    mode.add_argument('--prepare-only', action='store_true',
                      help='Save the 50 input shots and decoder matrices, without decoding')
    args = parser.parse_args()
    circuit, out = args.circuit.resolve(), args.output_dir.resolve()
    if not circuit.is_file():
        parser.error(f'Circuit does not exist: {circuit}')
    if args.input_samples is not None and not args.input_samples.is_file():
        parser.error(f'Saved input does not exist: {args.input_samples}')
    if (out / 'manifest.json').exists():
        parser.error(f'Refusing to overwrite an existing run: {out}')
    if hashlib.sha256(AUDITED_RUNNER.read_bytes()).hexdigest() != AUDITED_SHA256:
        raise RuntimeError('Audited detailed runner changed; review it before running.')
    if importlib.metadata.version('relay-bp') != '0.2.2':
        raise RuntimeError('This API audit requires installed relay-bp 0.2.2.')

    # Configure numerical libraries before the detailed runner imports them.
    os.environ['RAYON_NUM_THREADS'] = '64'
    for key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
        os.environ[key] = '1'
    namespace = runpy.run_path(str(AUDITED_RUNNER), run_name='audited_detailed_runner')
    if namespace['PARAMETERS'] != MODERN_PARAMETERS:
        raise RuntimeError('The audited runner does not contain the required parameters.')

    lock_path = Path(__file__).resolve().parent / '.decoder64.lock'
    with lock_path.open('a+') as lock:
        try:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise RuntimeError('Another single-instruction run owns the 64-thread budget; run the points sequentially.') from None
        invocation = dict(
            started_utc=datetime.now(timezone.utc).isoformat(),
            intended_physical_error_probability=args.p,
            source_circuit=os.path.relpath(circuit, out),
            circuit_sha256=hashlib.sha256(circuit.read_bytes()).hexdigest(),
            wrapper_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            audited_runner_sha256=AUDITED_SHA256,
            shots=50, sampler_seed=0, rayon_threads=64, processes=1,
            decoder_parameters=MODERN_PARAMETERS,
            legacy_table7=LEGACY_TABLE7,
            historical_backend_equivalence_proven=False,
            historical_equivalence_caveat=HISTORICAL_CAVEAT,
            noise_scope='Input circuit is used verbatim; --p is metadata only. Circuit construction must independently establish the intended noise and benchmark.',
            additional_decoder_or_postprocessing=False,
            expanded_equal_q=args.expanded_equal_q,
            mode='preflight_only' if args.preflight_only else 'prepare_only' if args.prepare_only else 'decode',
            sample_source='stim_circuit' if args.input_samples is None else os.path.relpath(args.input_samples.resolve(), out),
        )
        out.mkdir(parents=True, exist_ok=True)
        request_path = out / 'single_instruction_request.json'
        request_path.write_text(json.dumps(invocation, indent=2) + '\n')
        representation = preflight(circuit, out, args.p, expanded_equal_q=args.expanded_equal_q)
        print(json.dumps(representation, indent=2), flush=True)
        if args.preflight_only:
            return
        sys.argv = [str(AUDITED_RUNNER), '--circuit', str(circuit),
                    '--output-dir', str(out), '--shots', '50', '--seed', '0',
                    '--threads', '64', '--save-posteriors']
        if args.expanded_equal_q:
            folder = out / 'verified_expanded_graph'
            sys.argv.extend(['--check-matrix', str(folder/'check_matrix.npz'),
                             '--observable-matrix', str(folder/'observable_matrix.npz'),
                             '--error-priors', str(folder/'error_priors.npy')])
        if args.input_samples is not None:
            sys.argv.extend(['--input-samples', str(args.input_samples.resolve())])
        if args.prepare_only:
            sys.argv.append('--prepare-only')
        namespace['run']()

        manifest = json.loads((out / 'manifest.json').read_text())
        if args.prepare_only:
            assert manifest['status'] == 'prepared'
            assert manifest['decoder_parameters'] == json.loads(json.dumps(MODERN_PARAMETERS))
            assert manifest['decoded_shot_indices'] == list(range(50))
            print('Prepared input: no decoder was invoked. Use the audited checkpointed runner with this directory as --source-run.', flush=True)
            return
        summary = json.loads((out / 'summary.json').read_text())
        assert manifest['status'] == 'complete'
        assert manifest['decoder_parameters'] == json.loads(json.dumps(MODERN_PARAMETERS))
        assert manifest['sample_batch_size'] == summary['shots_decoded'] == 50
        assert manifest['decoded_shot_indices'] == list(range(50))
        assert manifest['threads'] == 64 and manifest['parallel'] is True
        assert manifest['sampler_seed'] == 0
        assert manifest['sample_source'] == ('stim_circuit' if args.input_samples is None else str(args.input_samples.resolve()))
        assert manifest['circuit_sha256'] == invocation['circuit_sha256']
        for key in ('all_returned_H_times_correction_match_reported_detectors',
                    'all_returned_O_times_correction_match_reported_observables',
                    'all_convergence_flags_match_zero_syndrome_residual',
                    'little_endian_input_roundtrip_exact'):
            assert summary[key] is True
        independently_check_saved_results(out)
        audit = dict(
            status='complete', completed_utc=datetime.now(timezone.utc).isoformat(),
            intended_physical_error_probability=args.p, shots=50,
            observable_mismatches=summary['logical_failures'],
            invalid_corrections=summary['syndrome_residual_shots'],
            valid_and_correct=summary['converged_correct'],
            invalid_or_observable_mismatch=50-summary['converged_correct'],
            observation='Nonconvergence and observable mismatch are separate recorded outcomes; neither is silently substituted for the other.',
            audited_modern_gross_parameters_unchanged=True,
            historical_backend_equivalence_proven=False,
            legacy_table7=LEGACY_TABLE7,
            historical_equivalence_caveat=HISTORICAL_CAVEAT,
            raw_dem_to_adapter_representation_verified=True,
            independently_rechecked_Hc_Oc_and_convergence_flags=True,
            zero_observable_errors_one_sided_95_upper=(
                -math.expm1(math.log(0.05)/50) if summary['logical_failures'] == 0 else None),
            zero_invalid_or_observable_errors_one_sided_95_upper=(
                -math.expm1(math.log(0.05)/50) if summary['converged_correct'] == 50 else None),
            confidence_scope='Exact binomial one-sided 95% upper bound for zero events in 50 independent shots; 0/50 does not establish LER near 1e-5.',
            source_inputs_and_per_shot_results_saved=True,
            expanded_equal_q=args.expanded_equal_q,
        )
        (out / 'single_instruction_audit.json').write_text(json.dumps(audit, indent=2) + '\n')
        print(json.dumps(audit, indent=2), flush=True)


if __name__ == '__main__':
    main()
