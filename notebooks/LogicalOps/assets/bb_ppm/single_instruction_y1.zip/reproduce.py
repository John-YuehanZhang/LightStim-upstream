"""Rebuild and rerun the archived benchmark in an installed LightStim checkout.

Usage after extracting the archive into its own directory:
  /path/to/checkout/venv/bin/python reproduce.py --repo /path/to/checkout \
      --output-dir /path/to/new/results

This performs new sampling and decoding: 50 shots at each of the two p values.
"""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import sys


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    here, repo, out = Path(__file__).resolve().parent, args.repo.resolve(), args.output_dir.resolve()
    if out.exists():
        parser.error('Use a new output directory to preserve previous samples.')
    if not (repo/'lightstim').is_dir():
        parser.error('--repo must be the LightStim source checkout.')
    sys.path[:0] = [str(here), str(repo)]
    os.environ['RAYON_NUM_THREADS'] = '64'
    for key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
        os.environ[key] = '1'
    builder = load('archived_single_y1_builder', here/'builder.py')
    builder.REPO = repo
    builder.HERE = here
    metadata = builder.write_artifacts(out/'circuits', rounds=10, schedule='paper12')
    runner = load('archived_single_y1_runner', here/'decoder_runner.py')
    runner.AUDITED_RUNNER = here/'diagnose_decoder.py'
    for case in metadata['noise_cases']:
        p = case['p']
        sys.argv = ['decoder_runner.py', '--circuit', str(out/'circuits'/case['circuit']),
                    '--p', str(p), '--output-dir', str(out/'runs'/f'p_{p:g}')]
        runner.main()
    print(json.dumps({'status':'complete', 'noise_points':[c['p'] for c in metadata['noise_cases']],
                      'shots_per_noise_point':50, 'threads':64}))


if __name__ == '__main__':
    main()
